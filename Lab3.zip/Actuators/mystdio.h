/*
 * mystdio.h
 *
 *  Created on: Feb 22, 2020
 *      Author: mdiannna
 */

#ifndef MYSTDIO_H_
#define MYSTDIO_H_

void InitSerial();

#endif /* MYSTDIO_H_ */
