
#ifndef LIGHT_H_
#define LIGHT_H_

void InitLight();
void LightOn();
void LightOff();
int IsLightOn();

#endif