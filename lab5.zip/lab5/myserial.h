#ifndef MYSERIAL_H_
#define MYSERIAL_H_

void SerialInit();

#endif
