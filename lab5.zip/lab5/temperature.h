
#ifndef TEMPERATURE_h
#define TEMPERATURE_h

// Change to respective sensor
#define TEMPERATURE_SENSOR_PIN 1

float ReadTemperature();
void ExampleTemperature();

#endif