
#ifndef MYPID_H_
#define MYPID_H_


void PID_Init();
void PID_SetInput(double input);
double PID_GetOutput();

#endif