#ifndef _BUTTON_H_
#define _BUTTON_H_

#include <Arduino.h>

#define BUTTON_PIN 8

void ButtonInit();
int ReadButton();	

#endif
