#include <Arduino.h>

void SerialInit() {
   Serial.begin(9600);
}
