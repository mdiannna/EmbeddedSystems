#ifndef ENCODER_H_
#define ENCODER_H_

#define ENCODER_PIN 6 

void EncoderInit();
double ReadEncoderValue();

#endif
