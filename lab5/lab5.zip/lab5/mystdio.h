
#ifndef MYSTDIO_H_
#define MYSTDIO_H_

void MystdioInit();

#endif