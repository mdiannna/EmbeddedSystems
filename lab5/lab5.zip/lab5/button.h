
#ifndef BUTTON_H_
#define BUTTON_H_

#define BUTTON_PIN 7
#define BUTTON_PRESSED 1
#define BUTTON_RELEASED 0


void ButtonInit();
int IsButtonPressed();
int isButtonReleased();


#endif
