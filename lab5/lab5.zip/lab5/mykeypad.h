
#ifndef MYKEYPAD_H_
#define MYKEYPAD_H_

#include <Arduino.h>
#include <Keypad.h>

extern Keypad kpd;

char GetCharKeypad();

#endif
