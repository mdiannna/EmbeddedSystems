
#ifndef MYKEYPAD_H_
#define MYKEYPAD_H_

char GetCharKeypad();

int PasswordIsCorrect(char * password);
char* ReadPassword();

#endif
